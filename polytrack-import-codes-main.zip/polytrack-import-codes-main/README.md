# polytrack-import-codes
Codes for the maps that I have made in Polytrack.
Some maps are 'lite' this means that all unnecessary scenery has been removed for performance purposes.
Play the game here: https://kodub.itch.io/polytrack
